﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using AdminProject.Data;
using AdminProject.Models;
using Microsoft.Data.SqlClient;

namespace AdminProject.Pages.Members
{
    public class EditModel : PageModel
    {
        [BindProperty]
        public AllMembers AllMembers { get; set; }

        public void OnGet(int? id)
        {
            string dbconnection = @"Data Source = (localdb)\MSSQLLocalDB; Initial Catalog = AllMembers; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False";


            SqlConnection conn = new SqlConnection(dbconnection);
            conn.Open();

            AllMembers = new AllMembers();

            using(SqlCommand command = new SqlCommand())
            {
                command.Connection = conn;
                command.CommandText = @"SELECT * FROM UsersTable WHERE Id = " + id;

                SqlDataReader read = command.ExecuteReader();

                while(read.Read())
                {
                    AllMembers.Username = read.GetString(1);
                    AllMembers.FirstName = read.GetString(2);
                    AllMembers.LastName = read.GetString(3);
                    AllMembers.Email = read.GetString(4);
                    AllMembers.Password = read.GetString(5);
                    AllMembers.Role = read.GetString(6);

                }
                read.Close();
            }
        }

        public IActionResult OnPost(int? id)
        {
            string dbconnection = @"Data Source = (localdb)\MSSQLLocalDB; Initial Catalog = AllMembers; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False";


            SqlConnection conn = new SqlConnection(dbconnection);
            conn.Open();

            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = conn;
                command.CommandText = @"UPDATE UsersTable SET Username = @UName, FirstName = @FName, LastName = @LName, Email = @Email, Password = @Pass, Role = @Role WHERE id = " + id;

                if (ModelState.IsValid)
                {
                    command.Parameters.AddWithValue("@UName", AllMembers.Username);
                    command.Parameters.AddWithValue("@FName", AllMembers.FirstName);
                    command.Parameters.AddWithValue("@LName", AllMembers.LastName);
                    command.Parameters.AddWithValue("@Email", AllMembers.Email);
                    command.Parameters.AddWithValue("@Pass", AllMembers.Password);
                    command.Parameters.AddWithValue("@Role", AllMembers.Role);
                }
                else
                {
                    return Page();
                }

                command.ExecuteNonQuery();
            }
            return RedirectToPage("Index");
            
        }
  
    }
}
